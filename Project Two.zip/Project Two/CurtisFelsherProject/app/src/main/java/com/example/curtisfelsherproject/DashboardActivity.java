package com.example.curtisfelsherproject;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;

public class DashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Sets view for activity
        setContentView(R.layout.activity_dashboard);

        // Finds EditText and Buttons from the view
        EditText goalWeightEditText = findViewById(R.id.goalWeightEditText);
        Button recordWeightButton = findViewById(R.id.recordWeightButton);
        Button notificationsButton = findViewById(R.id.notificationsButton);

        // Sets listener for button to open DataDisplayActivity
        recordWeightButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, DataDisplayActivity.class);
            startActivity(intent);
        });

        // Sets listener for button to open PermissionsActivity
        notificationsButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, PermissionsActivity.class);
            startActivity(intent);
        });
    }
}
