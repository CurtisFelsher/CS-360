package com.example.curtisfelsherproject;

import android.content.Intent;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class PermissionsActivity extends AppCompatActivity {

    // Array to track if notifications are enabled
    private final boolean[] isEnabled = {true};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Sets view for activity
        setContentView(R.layout.activity_permissions);

        // Finds the buttons from view
        Button notificationButton = findViewById(R.id.notificationButton);
        Button dashboardButton = findViewById(R.id.dashboardButton);
        Button recordWeightButton = findViewById(R.id.recordWeightButton);

        // Listener for notificationButton to toggle its enabled state
        notificationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isEnabled[0]) {
                    notificationButton.setText("Disabled");
                    isEnabled[0] = false;
                } else {
                    notificationButton.setText("Enabled");
                    isEnabled[0] = true;
                }
            }
        });

        // Sets listener for button to open DashboardActivity
        dashboardButton.setOnClickListener(v -> {
            Intent intent = new Intent(PermissionsActivity.this, DashboardActivity.class);
            startActivity(intent);
        });

        // Sets listener for button to open DataDisplayActivity
        recordWeightButton.setOnClickListener(v -> {
            Intent intent = new Intent(PermissionsActivity.this, DataDisplayActivity.class);
            startActivity(intent);
        });
    }
}