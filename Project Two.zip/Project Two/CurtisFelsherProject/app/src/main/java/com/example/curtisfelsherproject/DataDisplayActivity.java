package com.example.curtisfelsherproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {

    // Inner class for WeightEntry
    public static class WeightEntry {
        private String date;
        private float weight;

        // WeightEntry class constructor
        public WeightEntry(String date, float weight) {
            this.date = date;
            this.weight = weight;
        }

        // Getter and setter for date
        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        // Getter and setter for weight
        public float getWeight() {
            return weight;
        }

        public void setWeight(float weight) {
            this.weight = weight;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Sets view for activity
        setContentView(R.layout.activity_data_display);

        // Finds recyclerview from view
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerView);

        // Sample data just to show
        List<WeightEntry> dataList = new ArrayList<>();
        dataList.add(new WeightEntry("06-02-2023", 60.5f));
        dataList.add(new WeightEntry("06-03-2023", 61.0f));
        dataList.add(new WeightEntry("06-04-2023", 60.7f));

        // Creates DataAdapter for recyclerview
        DataAdapter adapter = new DataAdapter(dataList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Find the dashboard and notification buttons
        Button dashboardButton = findViewById(R.id.dashboardButton);
        Button notificationsButton = findViewById(R.id.notificationsButton);

        // Sets listener for button to open DashboardActivity
        dashboardButton.setOnClickListener(v -> {
            Intent intent = new Intent(DataDisplayActivity.this, DashboardActivity.class);
            startActivity(intent);
        });

        // Sets listener for button to open PermissionsActivity
        notificationsButton.setOnClickListener(v -> {
            Intent intent = new Intent(DataDisplayActivity.this, PermissionsActivity.class);
            startActivity(intent);
        });
    }

    // DataAdapter Class
    public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {
        private List<WeightEntry> dataList;

        // Viewholder class for DataAdapter
        public class ViewHolder extends RecyclerView.ViewHolder {
            public EditText dateInput;
            public EditText weightInput;
            public Button addButton;
            public Button removeButton;

            // Viewholder class constructor
            public ViewHolder(View view) {
                super(view);
                // Finds EditTexts and Buttons from view
                dateInput = (EditText) view.findViewById(R.id.dateInput);
                weightInput = (EditText) view.findViewById(R.id.weightInput);
                addButton = (Button) view.findViewById(R.id.addButton);
                removeButton = (Button) view.findViewById(R.id.removeButton);
            }
        }

        // DataAdapter Class constructor
        public DataAdapter(List<WeightEntry> dataList) {
            this.dataList = dataList;
        }

        @Override
        // Creates new ViewHolder for recyclerview
        public DataAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.grid_item, parent, false);
            return new ViewHolder(itemView);
        }

        @Override
        // Binds data to the ViewHolder
        public void onBindViewHolder(DataAdapter.ViewHolder holder, int position) {
            WeightEntry entry = dataList.get(position);
            holder.dateInput.setText(entry.getDate());
            holder.weightInput.setText(String.valueOf(entry.getWeight()));
        }

        @Override
        // Returns size of datalist
        public int getItemCount() {
            return dataList.size();
        }
    }
}
