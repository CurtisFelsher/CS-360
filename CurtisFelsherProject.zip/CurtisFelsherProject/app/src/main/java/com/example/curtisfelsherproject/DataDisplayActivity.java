package com.example.curtisfelsherproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.content.SharedPreferences;
import android.widget.Toast;
import android.telephony.SmsManager;
import android.content.ContentValues;

import java.util.ArrayList;
import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {

    // Declare private UserDBHelper and SQLiteDatabase objects and an integer for currentUserId
    private UserDBHelper dbHelper;
    private SQLiteDatabase db;
    private int currentUserId;
    // Declare a list to hold data
    private List<WeightEntry> dataList;

    // Declare a public class for weight entries
    public class WeightEntry {
        public String id;
        private String date;
        private float weight;

        // Constructor for the WeightEntry class
        public WeightEntry(String id, String date, float weight) {
            // Initialize id, date, and weight
            this.id = id;
            this.date = date;
            this.weight = weight;
        }

        public String getId() {
            return id;
        }

        public String getDate() {
            return date;
        }

        public float getWeight() {
            return weight;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        // Initialize UserDBHelper object with context
        dbHelper = new UserDBHelper(this);
        // Get a writable database from the dbHelper
        db = dbHelper.getWritableDatabase();

        // Initialize UI elements
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        Button addNewWeightEntryRowButton = findViewById(R.id.button);
        Button dashboardButton = findViewById(R.id.dashboardButton);
        Button notificationsButton = findViewById(R.id.notificationsButton);

        // Get a SharedPreferences object
        SharedPreferences sharedPreferences = getSharedPreferences(DashboardActivity.SHARED_PREFS, MODE_PRIVATE);
        // Get user id from shared preferences. Default is -1
        currentUserId = sharedPreferences.getInt("currentUserId", -1);

        // Initialize the dataList and refresh the data
        dataList = new ArrayList<>();
        refreshData();

        // Create a new DataAdapter and set it as the adapter for the recyclerView
        DataAdapter adapter = new DataAdapter(dataList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        addNewWeightEntryRowButton.setOnClickListener(v -> {
            // Create a new WeightEntry and add it to the dataList
            WeightEntry newEntry = new WeightEntry("", "", 0f);
            dataList.add(newEntry);
            // Notify the adapter that an item has been inserted
            adapter.notifyItemInserted(dataList.size() - 1);
        });

        dashboardButton.setOnClickListener(v -> {
            // Create intent to navigate from DataDisplayActivity to DashboardActivity
            Intent intent = new Intent(DataDisplayActivity.this, DashboardActivity.class);
            startActivity(intent);
        });

        notificationsButton.setOnClickListener(v -> {
            // Create intent to navigate from DataDisplayActivity to PermissionsActivity
            Intent intent = new Intent(DataDisplayActivity.this, PermissionsActivity.class);
            startActivity(intent);
        });
    }

    // Method to refresh the data in the dataList
    private void refreshData() {
        // Clear the dataList
        dataList.clear();
        // Query the database and store the results in a Cursor object
        Cursor cursor = db.query(UserDBHelper.TABLE_WEIGHTS, null, UserDBHelper.COLUMN_USER_ID + "=? AND " + UserDBHelper.COLUMN_IS_GOAL + " = 0", new String[]{String.valueOf(currentUserId)}, null, null, null);

        // Loop through the results
        while (cursor.moveToNext()) {
            // Get the id, date, and weight for each row and store them in variables
            String id = cursor.getString(cursor.getColumnIndex(UserDBHelper.COLUMN_ID));
            String date = cursor.getString(cursor.getColumnIndex(UserDBHelper.COLUMN_DATE));
            float weight = cursor.getFloat(cursor.getColumnIndex(UserDBHelper.COLUMN_WEIGHT));
            // Add a new WeightEntry to the dataList with the id, date, and weight
            dataList.add(new WeightEntry(id, date, weight));
        }
        cursor.close();
    }

    @Override
    protected void onResume() {
        // Call the onResume method from the parent class
        super.onResume();
        // Refresh the data when the activity comes into the foreground
        refreshData();

        SharedPreferences sharedPreferences = getSharedPreferences(DashboardActivity.SHARED_PREFS, MODE_PRIVATE);
    }

    // Method to get the goal weight from the database
    private float getGoalWeight() {
        // Query the database and store the results in a Cursor object
        Cursor cursor = db.query(UserDBHelper.TABLE_WEIGHTS, new String[]{UserDBHelper.COLUMN_WEIGHT},
                UserDBHelper.COLUMN_USER_ID + "=? AND " + UserDBHelper.COLUMN_IS_GOAL + " = 1",
                new String[]{String.valueOf(currentUserId)}, null, null, null);

        // If there is a result, get the goal weight and return it
        if (cursor.moveToFirst()) {
            float goalWeight = cursor.getFloat(cursor.getColumnIndex(UserDBHelper.COLUMN_WEIGHT));
            cursor.close();
            return goalWeight;
        } else {
            // If there are no results, return -1
            cursor.close();
            return -1;
        }
    }

    // Declares public class for the DataAdapter that extends RecyclerView.Adapter
    public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {
        private List<WeightEntry> dataList;

        public class ViewHolder extends RecyclerView.ViewHolder {
            public EditText dateInput;
            public EditText weightInput;
            public Button addButton;
            public Button removeButton;

            public ViewHolder(View view) {
                super(view);
                dateInput = view.findViewById(R.id.dateInput);
                weightInput = view.findViewById(R.id.weightInput);
                addButton = view.findViewById(R.id.addButton);
                removeButton = view.findViewById(R.id.removeButton);

                addButton.setOnClickListener(v -> {
                    // Get the date and weight from the EditTexts and store them in variables
                    String date = dateInput.getText().toString();
                    float weight = Float.parseFloat(weightInput.getText().toString());
                    // Get the WeightEntry for the current position in the dataList
                    WeightEntry entry = dataList.get(getAdapterPosition());

                    // Create a ContentValues object and put the date, weight, and user id
                    ContentValues contentValues = new ContentValues();
                    contentValues.put(UserDBHelper.COLUMN_DATE, date);
                    contentValues.put(UserDBHelper.COLUMN_WEIGHT, weight);
                    contentValues.put(UserDBHelper.COLUMN_IS_GOAL, 0);
                    contentValues.put(UserDBHelper.COLUMN_USER_ID, currentUserId);

                    // If id is empty, insert new values into the database and set id to the row id
                    if (entry.getId().isEmpty()) {
                        long newRowId = db.insert(UserDBHelper.TABLE_WEIGHTS, null, contentValues);
                        entry.id = String.valueOf(newRowId);
                        // Show a toast message to indicate that the weight was added
                        Toast.makeText(DataDisplayActivity.this, "Weight added", Toast.LENGTH_SHORT).show();
                    } else {
                        // If the id is not empty, update the values in the database
                        db.update(UserDBHelper.TABLE_WEIGHTS, contentValues, UserDBHelper.COLUMN_ID + "=?", new String[]{entry.getId()});
                        // Show a toast message to indicate that the weight was updated
                        Toast.makeText(DataDisplayActivity.this, "Weight updated", Toast.LENGTH_SHORT).show();
                    }

                    // Refresh the data
                    refreshData();

                    // Get the goal weight

                    float goalWeight = getGoalWeight();
                    if (goalWeight > 0 && weight <= goalWeight) {
                        // Get the phoneNumber and disableSMS directly from the DBHelper instead of SharedPreferences
                        String phoneNumber = dbHelper.getUserPhoneNumber(currentUserId);
                        boolean disableNotifications = dbHelper.getDisableSMS(currentUserId);
                        if (!phoneNumber.isEmpty() && !disableNotifications) {
                            SmsManager smsManager = SmsManager.getDefault();
                            smsManager.sendTextMessage(phoneNumber, null, "Congratulations! You've reached your goal weight.", null, null);
                        } else if (disableNotifications) {
                            Toast.makeText(DataDisplayActivity.this, "Notifications are currently disabled.", Toast.LENGTH_SHORT).show();
                        }
                    }

                });


                removeButton.setOnClickListener(v -> {
                    // Get the WeightEntry for the current position in the dataList
                    WeightEntry entry = dataList.get(getAdapterPosition());
                    // Delete the entry from the database
                    db.delete(UserDBHelper.TABLE_WEIGHTS, UserDBHelper.COLUMN_ID + "=?", new String[]{entry.getId()});
                    // Remove the entry from the dataList
                    dataList.remove(getAdapterPosition());
                    // Notify the adapter that an item has been removed
                    notifyItemRemoved(getAdapterPosition());

                    // Refresh the data
                    refreshData();
                });
            }
        }

        public DataAdapter(List<WeightEntry> dataList) {
            // Initialize the dataList from the constructor parameter
            this.dataList = dataList;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            // Inflate the grid_item.xml layout and create new ViewHolder with it
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_item, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            // Get the WeightEntry for the current position
            WeightEntry entry = dataList.get(position);
            // Set the text of the dateInput and weightInput to the date and weight of the entry
            holder.dateInput.setText(entry.getDate());
            holder.weightInput.setText(Float.toString(entry.getWeight()));
        }

        @Override
        public int getItemCount() {
            // Return the size of the dataList
            return dataList.size();
        }
    }
}



