package com.example.curtisfelsherproject;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class PermissionsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 0;

    private UserDBHelper userDBHelper;
    private int userId;

    private TextView userPhoneNumber;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permissions);

        // Initialize UserDBHelper with context
        userDBHelper = new UserDBHelper(this);

        // Get the shared preferences associated with the DashboardActivity
        SharedPreferences sharedPreferences = getSharedPreferences(DashboardActivity.SHARED_PREFS, MODE_PRIVATE);

        // Get the current user id from shared preferences. Defaults to -1 if not found
        userId = sharedPreferences.getInt("currentUserId", -1);

        // Find the TextView that will display the user's phone number and the update from the database
        userPhoneNumber = findViewById(R.id.userPhoneNumber);
        updatePhoneNumberText();

        // Find the Buttons in the layout
        Button notificationButton = findViewById(R.id.notificationButton);
        Button dashboardButton = findViewById(R.id.dashboardButton);
        Button recordWeightButton = findViewById(R.id.recordWeightButton);
        Button disableButton = findViewById(R.id.disableButton);

        // Set the onClick listener for the notificationButton
        notificationButton.setOnClickListener(v -> {

            // Check if the app has SMS permissions
            if (ContextCompat.checkSelfPermission(PermissionsActivity.this,
                    Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                // Request SMS permissions if not already granted
                ActivityCompat.requestPermissions(PermissionsActivity.this,
                        new String[] {Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
            } else {
                // If the app already has SMS permissions, prompt user to enter phone number
                requestPhoneNumber();
                // Set the "disableSMS" shared preference to false, enabling SMS
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putBoolean("disableSMS", false); // enable SMS when user taps the notifications button
                editor.apply();
                // If a valid user id is present, update "disableSMS" within the database
                if(userId != -1){
                    userDBHelper.updateDisableSMS(userId, false);
                }
            }
        });

        dashboardButton.setOnClickListener(v -> {
            // Create a new Intent to launch the DashboardActivity
            Intent intent = new Intent(PermissionsActivity.this, DashboardActivity.class);
            startActivity(intent);
        });

        recordWeightButton.setOnClickListener(v -> {
            // Create a new Intent to launch the DataDisplayActivity
            Intent intent = new Intent(PermissionsActivity.this, DataDisplayActivity.class);
            startActivity(intent);
        });

        disableButton.setOnClickListener(v -> {
            // Set the "disableSMS" shared preference to true, disabling SMS
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("disableSMS", true);
            editor.apply();
            // If a valid user id is present, update "disableSMS" within the database
            if(userId != -1){
                userDBHelper.updateDisableSMS(userId, true);
            }
            // Displays a Toast message indicating that notifications have been disabled
            Toast.makeText(PermissionsActivity.this, "Notifications disabled", Toast.LENGTH_SHORT).show();
        });
    }

    // Method to prompt the user to enter their phone number
    private void requestPhoneNumber() {
        // Create a new AlertDialog.Builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        // Set the title of the AlertDialog
        builder.setTitle("Enter your phone number:");

        // Create an EditText for the user to enter their phone number
        final EditText input = new EditText(this);
        input.setText("+1");
        // Set the AlertDialog to display the EditText
        builder.setView(input);

        // Set the "OK" button of the AlertDialog, which will save the phone number
        builder.setPositiveButton("OK", (dialog, which) -> {
            // Get the entered phone number from the EditText
            String phoneNumber = input.getText().toString();
            // If a user id is present, save the entered phone number to the database and shared preferences
            if(userId != -1){
                userDBHelper.updateUserPhoneNumber(userId, phoneNumber);
                SharedPreferences.Editor editor = getSharedPreferences(DashboardActivity.SHARED_PREFS, MODE_PRIVATE).edit();
                editor.putString("phoneNumber", phoneNumber);
                editor.apply();
                // Update the displayed phone number
                updatePhoneNumberText();
                // Show a Toast message indicating that the phone number has been updated
                Toast.makeText(this, "Phone number updated", Toast.LENGTH_SHORT).show();
            } else {
                // If no user id is present, show a Toast message indicating an error
                Toast.makeText(this, "Error: Unable to fetch user data", Toast.LENGTH_SHORT).show();
            }
        });
        // Set the "Cancel" button of the AlertDialog, closes the dialog
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    // Method that is called when the user responds to the app's permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Check if this response is for the SMS permission request
        if (requestCode == SMS_PERMISSION_CODE) {
            // If permission is granted, prompt the user to enter their phone number
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                requestPhoneNumber();
            } else {
                // If permission is not granted, show a Toast message indicating that SMS permission was denied
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Method to update displayed phone number by retrieving the number from the database
    private void updatePhoneNumberText() {
        String phoneNumber = userDBHelper.getUserPhoneNumber(userId);
        // Display phone number, or "N/A" if the number is null
        userPhoneNumber.setText("Phone Number: " + (phoneNumber != null ? phoneNumber : "N/A"));
    }

}

