package com.example.curtisfelsherproject;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.os.Bundle;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.content.ContentValues;

public class MainActivity extends AppCompatActivity {

    // SQLite Database and helper references
    private UserDBHelper dbHelper;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initializes dbHelper object and db object by acquiring writeable access to the database
        dbHelper = new UserDBHelper(this);
        db = dbHelper.getWritableDatabase();

        // References to UI elements from the layout resource
        EditText usernameEditText = findViewById(R.id.userField);
        EditText passwordEditText = findViewById(R.id.passField);
        Button loginButton = findViewById(R.id.loginButton);
        Button newUserButton = findViewById(R.id.newUserButton);

        loginButton.setOnClickListener(v -> {
            // Extracts the text from the EditText fields
            String username = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            // Retrieves the matching user from the database using the provided username and password
            Cursor cursor = db.rawQuery("SELECT * FROM " + UserDBHelper.TABLE_USERS + " WHERE " +
                            UserDBHelper.COLUMN_USERNAME + "=? AND " + UserDBHelper.COLUMN_PASSWORD + "=?",
                    new String[] {username, password});

            // Checks if a user was found
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();

                // Extracts the userId, disableSMS, and phoneNumber values from the cursor
                int userId = cursor.getInt(cursor.getColumnIndex(UserDBHelper.COLUMN_ID));
                boolean disableSMS = dbHelper.getDisableSMS(userId);
                String phoneNumber = dbHelper.getUserPhoneNumber(userId);

                // Stores the userId, disableSMS, and phoneNumber in shared preferences
                SharedPreferences sharedPreferences = getSharedPreferences(DashboardActivity.SHARED_PREFS, MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("currentUserId", userId);
                editor.putBoolean("disableSMS", disableSMS);
                editor.putString("phoneNumber", phoneNumber);
                editor.apply();

                // Navigates to DashboardActivity
                Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
                startActivity(intent);
            } else {
                // Shows message when the provided username or password is incorrect
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
            // Closes the cursor to free up resources
            cursor.close();
        });

        newUserButton.setOnClickListener(v -> {
            // Extracts the text from the EditText fields
            String username = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            // Checks if username or password is empty and shows a message if so
            if(username.isEmpty() || password.isEmpty()){
                Toast.makeText(this, "Username and password should not be blank", Toast.LENGTH_SHORT).show();
                return;
            }

            // Checks if the username already exists in the database
            Cursor cursor = db.query(UserDBHelper.TABLE_USERS,
                    new String[] {UserDBHelper.COLUMN_USERNAME},
                    "lower(" + UserDBHelper.COLUMN_USERNAME + ")=?",
                    new String[] {username.toLowerCase()},
                    null, null, null, null);

            if (cursor.getCount() > 0) {
                // Shows message if the username already exists
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
                cursor.close();
                return;
            }
            cursor.close();

            // Prepares the ContentValues object with the user data
            ContentValues contentValues = new ContentValues();
            contentValues.put(UserDBHelper.COLUMN_USERNAME, username);
            contentValues.put(UserDBHelper.COLUMN_PASSWORD, password);
            // Set disableSMS to true for new users
            contentValues.put(UserDBHelper.COLUMN_DISABLE_SMS, 1);
            // Set phoneNumber to an empty string for new users
            contentValues.put(UserDBHelper.COLUMN_PHONE_NUMBER, "");

            // Inserts the new user into the database.
            long userId = db.insert(UserDBHelper.TABLE_USERS, null, contentValues);

            // Save the user ID to SharedPreferences
            SharedPreferences sharedPreferences = getSharedPreferences(DashboardActivity.SHARED_PREFS, MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            // Convert long to int because SharedPreferences does not support long
            editor.putInt("currentUserId", (int) userId);
            // Set disableSMS to true for new users
            editor.putBoolean("disableSMS", true);
            // Set phoneNumber to an empty string for new users
            editor.putString("phoneNumber", "");
            editor.apply();

            // Shows a message indicating that the user was created.
            Toast.makeText(this, "User created", Toast.LENGTH_SHORT).show();
        });
    }
}
