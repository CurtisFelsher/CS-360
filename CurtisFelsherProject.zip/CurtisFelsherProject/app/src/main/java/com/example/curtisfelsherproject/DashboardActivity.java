package com.example.curtisfelsherproject;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class DashboardActivity extends AppCompatActivity {

    public static final String SHARED_PREFS = "sharedPrefs" ;
    private UserDBHelper dbHelper;
    private SQLiteDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Initialize the database helper
        dbHelper = new UserDBHelper(this);
        db = dbHelper.getWritableDatabase();

        EditText goalWeightEditText = findViewById(R.id.goalWeightEditText);
        Button recordWeightButton = findViewById(R.id.recordWeightButton);
        Button notificationsButton = findViewById(R.id.notificationsButton);
        Button logoutButton = findViewById(R.id.logoutButton);
        Button goalButton = findViewById(R.id.goalButton);

        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        int currentUserId = sharedPreferences.getInt("currentUserId", -1);

        float savedGoalWeight = dbHelper.getUserGoalWeight(currentUserId);

        // Display the user's goal weight in the EditText
        goalWeightEditText.setText(String.format(Locale.getDefault(), "%.2f", savedGoalWeight));

        recordWeightButton.setOnClickListener(v -> {
            // Retrieves the entered goal weight
            String goalWeightStr = goalWeightEditText.getText().toString();
            // Check if entered goal weight is not empty
            if (!goalWeightStr.isEmpty()) {
                // Convert the goal weight to float
                float goalWeight = Float.parseFloat(goalWeightStr);

                // Check if goal weight was updated successfully in the user profile
                int rowsUpdated = dbHelper.updateUserGoalWeight(currentUserId, goalWeight);
                // If the update was successful, display a success message
                if(rowsUpdated > 0) {
                    Toast.makeText(DashboardActivity.this, "Goal weight saved", Toast.LENGTH_SHORT).show();
                }

                // Create a new set of values for the goal weight
                ContentValues values = new ContentValues();
                values.put(UserDBHelper.COLUMN_WEIGHT, goalWeight);
                values.put(UserDBHelper.COLUMN_USER_ID, currentUserId);
                values.put(UserDBHelper.COLUMN_IS_GOAL, 1);

                // Insert the new goal weight into the weights table
                db.insert(UserDBHelper.TABLE_WEIGHTS, null, values);
                // Fetch the updated goal weight from the database
                float updatedGoalWeight = dbHelper.getUserGoalWeight(currentUserId);
                // Display the updated goal weight in the EditText
                goalWeightEditText.setText(String.format(Locale.getDefault(), "%.2f", updatedGoalWeight));

                // Create a new intent to launch the DataDisplayActivity
                Intent intent = new Intent(DashboardActivity.this, DataDisplayActivity.class);
                startActivity(intent);
            } else {
                // If no goal weight was entered, display message
                Toast.makeText(DashboardActivity.this, "Please enter goal weight", Toast.LENGTH_SHORT).show();
            }
        });

        notificationsButton.setOnClickListener(v -> {
            String goalWeightStr = goalWeightEditText.getText().toString();
            if (!goalWeightStr.isEmpty()) {
                float goalWeight = Float.parseFloat(goalWeightStr);

                // Check if goal weight was updated successfully in the user's profile
                int rowsUpdated = dbHelper.updateUserGoalWeight(currentUserId, goalWeight);
                if(rowsUpdated > 0) {
                    Toast.makeText(DashboardActivity.this, "Goal weight saved", Toast.LENGTH_SHORT).show();
                }

                // Save the goal weight in the weights table as well
                ContentValues values = new ContentValues();
                values.put(UserDBHelper.COLUMN_WEIGHT, goalWeight);
                values.put(UserDBHelper.COLUMN_USER_ID, currentUserId);
                values.put(UserDBHelper.COLUMN_IS_GOAL, 1);

                db.insert(UserDBHelper.TABLE_WEIGHTS, null, values);

                // Refresh the displayed goal weight
                float updatedGoalWeight = dbHelper.getUserGoalWeight(currentUserId);
                goalWeightEditText.setText(String.format(Locale.getDefault(), "%.2f", updatedGoalWeight));

                Intent intent = new Intent(DashboardActivity.this, PermissionsActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(DashboardActivity.this, "Please enter goal weight", Toast.LENGTH_SHORT).show();
            }
        });

        goalButton.setOnClickListener(v -> {
            String goalWeightStr = goalWeightEditText.getText().toString();
            if (!goalWeightStr.isEmpty()) {
                float goalWeight = Float.parseFloat(goalWeightStr);
                int rowsUpdated = dbHelper.updateUserGoalWeight(currentUserId, goalWeight);
                if (rowsUpdated > 0) {
                    Toast.makeText(DashboardActivity.this, "Goal weight updated", Toast.LENGTH_SHORT).show();
                    // Refresh the displayed goal weight
                    goalWeightEditText.setText(String.format(Locale.getDefault(), "%.2f", goalWeight));
                } else {
                    Toast.makeText(DashboardActivity.this, "Failed to update goal weight", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(DashboardActivity.this, "Please enter goal weight", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        // Close the database when the activity is destroyed
        dbHelper.close();
        super.onDestroy();
    }
}




