package com.example.curtisfelsherproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class UserDBHelper extends SQLiteOpenHelper {
    // Database name and version constants
    private static final String DATABASE_NAME = "UserDB";
    private static final int DATABASE_VERSION = 12;


    // Users table constants
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_GOAL_WEIGHT = "goalWeight";
    public static final String COLUMN_PHONE_NUMBER = "phoneNumber";
    public static final String COLUMN_DISABLE_SMS = "disableSMS";


    // Weights table constants
    public static final String COLUMN_IS_GOAL = "isGoal";
    public static final String TABLE_WEIGHTS = "weights";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_WEIGHT = "weight";
    public static final String COLUMN_USER_ID = "user_id";

    // SQL string to create the users table
    private static final String CREATE_TABLE_USERS = "CREATE TABLE " + TABLE_USERS + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_USERNAME + " TEXT,"
            + COLUMN_PASSWORD + " TEXT," + COLUMN_GOAL_WEIGHT + " REAL,"
            + COLUMN_PHONE_NUMBER + " TEXT," + COLUMN_DISABLE_SMS + " INTEGER DEFAULT 0" + ")";

    // SQL string to create the weights table
    private static final String CREATE_TABLE_WEIGHTS = "CREATE TABLE " + TABLE_WEIGHTS + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_DATE + " TEXT,"
            + COLUMN_WEIGHT + " REAL," + COLUMN_USER_ID + " INTEGER,"
            + COLUMN_IS_GOAL + " INTEGER DEFAULT 0,"
            + " FOREIGN KEY ("+COLUMN_USER_ID+") REFERENCES "+TABLE_USERS+"("+COLUMN_ID+"))";

    // Constructor
    public UserDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Called when the database is created for the first time
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the tables in the database
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_WEIGHTS);
    }

    // Called when the database needs to be upgraded
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop the old tables and create new ones
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        // Create the tables again
        onCreate(db);
    }

    // Update the user phone number
    public void updateUserPhoneNumber(int userId, String phoneNumber) {
        // Get writable access to the database
        SQLiteDatabase db = this.getWritableDatabase();

        // Prepare values for updating
        ContentValues values = new ContentValues();
        values.put(COLUMN_PHONE_NUMBER, phoneNumber);

        // Update the user's phone number in the database
        db.update(TABLE_USERS, values, COLUMN_ID + " = ?", new String[] {String.valueOf(userId)});
    }

    // Get the user's phone number
    public String getUserPhoneNumber(int userId) {
        // Get readable access to the database
        SQLiteDatabase db = this.getReadableDatabase();

        // Query the user's phone number from the database
        Cursor cursor = db.query(TABLE_USERS, new String[] { COLUMN_PHONE_NUMBER },
                COLUMN_ID + "=?", new String[] { String.valueOf(userId) },
                null, null, null, null);

        // Extract the phone number from the cursor
        if (cursor != null && cursor.moveToFirst()) {
            String phoneNumber = cursor.getString(0);
            cursor.close();
            return phoneNumber;
        } else {
            return null;
        }
    }

    // Update the user SMS preference
    public void updateDisableSMS(int userId, boolean disableSMS) {
        // Get writable access to the database
        SQLiteDatabase db = this.getWritableDatabase();

        // Prepare the values for updating
        ContentValues values = new ContentValues();
        values.put(COLUMN_DISABLE_SMS, disableSMS ? 1 : 0);

        // Update the user's SMS preference in the database
        db.update(TABLE_USERS, values, COLUMN_ID + " = ?", new String[] {String.valueOf(userId)});
    }

    // Get the user SMS preference
    public boolean getDisableSMS(int userId) {
        // Get readable access to the database
        SQLiteDatabase db = this.getReadableDatabase();

        // Query the user's SMS preference from the database\
        Cursor cursor = db.query(TABLE_USERS, new String[] { COLUMN_DISABLE_SMS },
                COLUMN_ID + "=?", new String[] { String.valueOf(userId) },
                null, null, null, null);
        // Extract the SMS preference from the cursor
        if (cursor != null && cursor.moveToFirst()) {
            boolean disableSMS = cursor.getInt(0) == 1;
            cursor.close();
            return disableSMS;
        } else {
            return false;
        }
    }

    // Update the user goal weight
    public int updateUserGoalWeight(int userId, float goalWeight) {
        // Get writable access to the database
        SQLiteDatabase db = this.getWritableDatabase();

        // Prepare the values for updating
        ContentValues values = new ContentValues();
        values.put(COLUMN_GOAL_WEIGHT, goalWeight);

        // Update user goal weight in the database and return the number of rows affected
        return db.update(TABLE_USERS, values, COLUMN_ID + " = ?", new String[] {String.valueOf(userId)});
    }

    // Get the user goal weight
    public float getUserGoalWeight(int userId) {
        // Get readable access to the database
        SQLiteDatabase db = this.getReadableDatabase();

        // Query the user's goal weight from the database
        Cursor cursor = db.query(TABLE_USERS, new String[] { COLUMN_GOAL_WEIGHT },
                COLUMN_ID + "=?", new String[] { String.valueOf(userId) },
                null, null, null, null);

        // Extract goal weight from the cursor
        if (cursor != null && cursor.moveToFirst()) {
            float goalWeight = cursor.getFloat(0);
            cursor.close();
            return goalWeight;
        } else {
            return 0f;
        }
    }
}

